//José Manuel Molina Vargas
#include <iostream>
#include <string>
using namespace std;
void espacios(int espacio){ //Función generar espacios
	for(int i=0; i < espacio;i++){
		cout<<" ";
	}
}
void EscaleraDoble(int escalones, int persona){ //Función para imprimir la escalera y a la persona en el escalon correcto.
	int espacio=4, esp_largo;
	while(escalones > 0){ 
		esp_largo=8*(escalones-1)+5;
		if(persona==-(escalones)){ //Cuando la pesona esté en el lado positivo de la escalera.
			cout<<"|_P_";
			espacios(esp_largo);
			cout<<"___|";			
		}if(persona==escalones){//Cuando la pesona esté en el lado negativo de la escalera.
			cout<<"|___";
			espacios(esp_largo);
			cout<<"_P_|";			
		}if(persona!=escalones&&persona!=-(escalones)){ //Cuando la pesona esté en un escalon distinto.
			cout<<"|___";
			espacios(esp_largo);
			cout<<"___|";
		}
		escalones--;
		cout<<"\n";
		espacios(espacio);
		espacio+=4;
	}
	if(persona==0){ //Cuando la persona este en el piso
		cout<<"|_P_|";
	}else{//Cuando la persona no est en el piso
		cout<<"|___|";
	}
}
int main() {
	int escalones,animacion,escalon;
	cout<<"Ingrese el numero de escalones: ";cin>>escalones;//numero de escalones 
	cout<<"Cuantas veces quiere que la persona haga la animación: ";cin>>animacion;//veces que se realizara la animación.
	cout<<"En que escalon quiere que empiece la animación: ";cin>>escalon; //escalon en el que se empezará la animación.
	system("cls");
	while(animacion>0){ //bucle para que realice la animación "x" veces;
		for(int i=escalon ; i <= (escalones); i++){ //Para que la persona vaya a la derecha
			EscaleraDoble(escalones,i);
			cout<<"\n";
			system("pause"); //Pausar la pantalla
			system("cls"); //Borrar la pantalla
		}
		for(int i=(escalones)-1 ; i >= -(escalones); i--){ //Para que la persona vaya a la izquierda
			EscaleraDoble(escalones,i);
			cout<<"\n";
			system("pause");
			system("cls");
		}
		animacion--;
	}
	return 0;
}

