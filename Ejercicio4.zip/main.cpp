//José Manuel Molina Vargas
#include <iostream>
#include <string>
using namespace std;
void espacios(int espacio){ //Función para imprimir el espacio para que se vea la escalera.
	for(int i=0; i < espacio; i++){
		cout<<" ";
	}
}
void EscaleraDoble(int escalones, int persona){ //Función para imprimir la escalera y a la persona en el escalon correcto.
	int espacio=4;
  int esp_largo;
	while(escalones > 0){//bucle para fin de la escalera
		esp_largo=8*(escalones-1)+5;
		if(persona==-escalones){ //Cuando la pesona esté en el lado positivo de la escalera.
			cout<<" _P_";
			espacios(esp_largo);
			cout<<"___|";			
		}if(persona==(escalones)){//Cuando la pesona esté en el lado negativo de la escalera.
			cout<<"|___";
			espacios(esp_largo);
			cout<<"_P_";			
		}if(persona!=escalones&&persona!=-(escalones)){ //dibujo del escalon sin la persona.
			cout<<"|___";
			espacios(esp_largo);
			cout<<"___|";
		}
		escalones--; //Reduccion de escalones para la disminucion de espacios en la 2da escalera
		cout<<"\n";
		espacios(espacio);
		espacio+=4; //espacios debajo de las escaleras 4 espacios es = a "__"
	}
	if(persona==0){ //Cuando la persona este en el piso.
		cout<<"|_P_|";
	}else{//Cuando la persona no esté en el piso.
		cout<<"|___|";
	}
}
int main() {
	int escalones,escalon;
	cout<<"¿En que escalon esta la persona?: ";cin>>escalon; //escalon en el que se ubica la persona
	EscaleraDoble(3, escalon);
}

